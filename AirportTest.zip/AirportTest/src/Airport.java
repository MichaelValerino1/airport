/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 23valerim
 */
public class Airport {
    private String name = "empty";
    double longitude = 0;
    double latitude = 0;
    //methods with same name as class are constructors

        
        
        
     //end default constructor
    
    public Airport(String someName, double someLong, double someLat)
    {
        name = someName;
        longitude = someLong;
        latitude = someLat;
    }

    Airport() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    public String getName()
    {
        
        return name;
    }
    
    public double getLatitude()
    {
        
        return latitude;
    }
    
    public double getLongitude()
    {
        
        return longitude;
    }
}
